export type SpotlightNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7;

export type CrisisState =
  | 'intro'
  | 'spotlight-1'
  | 'spotlight-2'
  | 'spotlight-3'
  | 'spotlight-4'
  | 'spotlight-5'
  | 'spotlight-6'
  | 'spotlight-7'
  | 'action'
  | 'action-confirmation'
  | 'exited';

export type TimerState = 'running' | 'paused' | 'backgrounded';

export type SpotlightLength = 'short' | 'medium' | 'long' | 'very-long';

export type SpotlightCopy = {
  id: string;
  slot: SpotlightNumber;
  phase:
    | 'interrupt'
    | 'evidence'
    | 'body'
    | 'reframe'
    | 'encounter'
    | 'orientation'
    | 'action';
  headline: string;
  body: string[];
  alignment?: 'left' | 'center';
};

export type SpotlightViewData = {
  slot: SpotlightNumber;
  phase: SpotlightCopy['phase'];
  headline: string;
  body: string[];
  length: SpotlightLength;
  alignment: 'left' | 'center';
};

export type NotfallJourneyState = {
  currentStageDay: number;
  daysAfterToday: number;
  completedDays: number;
  startsOnLabel: string;
};

export type NotfallActionId =
  | 'washingPrayer'
  | 'meditation'
  | 'walking'
  | 'contact';

export type NotfallAction = {
  id: NotfallActionId;
  label: string;
  confirmation: string[];
};
