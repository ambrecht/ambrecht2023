import { useEffect, useMemo, useRef } from 'react';
import { useRouter } from 'next/router';

import { getSpotlightViewData, notfallActions } from '../copy/crisis';
import { useNotfallFlow } from '../hooks/useNotfallFlow';
import { getNotfallJourneyState } from '../lib/journey';
import { maxSpotlights, spotlightDurationMs } from '../lib/machine';
import type { NotfallActionId, SpotlightLength } from '../types';
import styles from './notfall.module.css';

const actionLookup = new Map(notfallActions.map((action) => [action.id, action]));

export function NotfallExperience() {
  const router = useRouter();
  const [state, dispatch] = useNotfallFlow();
  const headingRef = useRef<HTMLHeadingElement>(null);
  const journey = useMemo(() => getNotfallJourneyState(), []);
  const loggedActionRef = useRef(false);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        storeLocalEvent({ event: 'crisis_exited' });
        dispatch({ type: 'exit' });
      }
    }

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [dispatch]);

  useEffect(() => {
    if (state.status !== 'intro' && state.status !== 'exited') {
      headingRef.current?.focus({ preventScroll: true });
    }
  }, [state.status, 'slot' in state ? state.slot : null]);

  useEffect(() => {
    if (state.status === 'exited') {
      router.replace('/');
    }
  }, [router, state.status]);

  useEffect(() => {
    if (state.status !== 'action-confirmation' || loggedActionRef.current) {
      return;
    }

    loggedActionRef.current = true;
    storeLocalEvent({
      event: 'action_selected',
      actionId: state.actionId,
      timeToActionMs: Math.round(state.timeToActionMs),
    });
  }, [state]);

  const liveAnnouncement = isSpotlightViewState(state)
    ? `Schlaglicht ${state.slot} von 7`
    : state.status === 'action'
      ? 'Die Reflexion endet hier. Jetzt folgt eine Handlung.'
      : state.status === 'action-confirmation'
        ? 'Handlung ausgewaehlt.'
        : '';

  return (
    <main className={styles.root} aria-label="Notfallmodus">
      <div className={styles.srOnly} aria-live="polite" aria-atomic="true">
        {liveAnnouncement}
      </div>

      {state.status === 'intro' ? (
        <IntroScreen
          onStart={() => {
            storeLocalEvent({ event: 'crisis_started' });
            dispatch({ type: 'start', nowMs: performance.now() });
          }}
        />
      ) : null}

      {isSpotlightViewState(state) ? (
        <SpotlightScreen
          headingRef={headingRef}
          slot={state.slot}
          remainingMs={state.remainingMs}
          isPaused={state.timerState !== 'running'}
          journeyDay={journey.currentStageDay}
          spotlight={getSpotlightViewData(state.slot, journey)}
          onActionNow={() => {
            storeLocalEvent({
              event: 'action_now_clicked',
              spotlightIndex: state.slot,
              elapsedMs: Math.round(
                (state.slot - 1) * spotlightDurationMs +
                  (spotlightDurationMs - state.remainingMs),
              ),
            });
            dispatch({ type: 'action.now' });
          }}
          onPause={() => dispatch({ type: 'pause.user' })}
          onResume={() => dispatch({ type: 'resume.user' })}
          onExit={() => {
            storeLocalEvent({ event: 'crisis_exited' });
            dispatch({ type: 'exit' });
          }}
        />
      ) : null}

      {state.status === 'action' ? (
        <ActionScreen
          headingRef={headingRef}
          onSelect={(actionId) =>
            dispatch({ type: 'action.select', actionId, nowMs: performance.now() })
          }
        />
      ) : null}

      {state.status === 'action-confirmation' ? (
        <ActionSelectedScreen
          headingRef={headingRef}
          actionId={state.actionId}
          onExit={() => {
            storeLocalEvent({ event: 'crisis_exited' });
            dispatch({ type: 'exit' });
          }}
        />
      ) : null}
    </main>
  );
}

function IntroScreen({ onStart }: { onStart: () => void }) {
  return (
    <section className={styles.screen} aria-labelledby="notfall-intro-title">
      <div className={styles.topBar}>
        <span>NOTFALLMODUS</span>
        <span>70 SEKUNDEN - KEINE SCHLEIFE</span>
      </div>
      <div className={styles.centerStage}>
        <p className={styles.eyebrow}>NOTFALLMODUS - 70 SEKUNDEN - KEINE SCHLEIFE</p>
        <h1 id="notfall-intro-title" className={`${styles.title} ${styles.introTitle}`}>
          <span>SIEBEN</span>
          <span>SCHLAGLICHTER.</span>
        </h1>
        <p className={styles.lede}>
          Danach endet die Reflexion. Dann folgt eine Handlung.
        </p>
      </div>
      <div className={styles.bottomBar}>
        <button className={styles.primaryButton} type="button" onClick={onStart}>
          STARTEN
        </button>
      </div>
    </section>
  );
}

type SpotlightScreenProps = {
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  slot: number;
  remainingMs: number;
  isPaused: boolean;
  journeyDay: number;
  spotlight: {
    headline: string;
    body: string[];
    length: SpotlightLength;
    alignment: 'left' | 'center';
    phase: string;
  };
  onActionNow: () => void;
  onPause: () => void;
  onResume: () => void;
  onExit: () => void;
};

function SpotlightScreen({
  headingRef,
  slot,
  remainingMs,
  isPaused,
  journeyDay,
  spotlight,
  onActionNow,
  onPause,
  onResume,
  onExit,
}: SpotlightScreenProps) {
  const elapsedRatio =
    ((slot - 1) * spotlightDurationMs + (spotlightDurationMs - remainingMs)) /
    (spotlightDurationMs * maxSpotlights);
  const progressPercent = Math.min(Math.max(elapsedRatio * 100, 0), 100);

  return (
    <section
      className={`${styles.screen} ${styles.withProgress}`}
      aria-labelledby="notfall-spotlight-title"
    >
      <div className={styles.topBar}>
        <span>{slot} / {maxSpotlights}</span>
        <span>TAG {journeyDay}</span>
      </div>
      <div
        className={styles.progressTrack}
        role="progressbar"
        aria-label="Fortschritt"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(progressPercent)}
      >
        <span style={{ width: `${progressPercent}%` }} />
      </div>

      <div className={styles.centerStage}>
        <h1
          id="notfall-spotlight-title"
          className={[
            styles.title,
            styles[`spotlight${toCssName(spotlight.length)}`],
            styles[`align${toCssName(spotlight.alignment)}`],
            spotlight.phase === 'body' ? styles.bodySpotlight : '',
          ].join(' ')}
          ref={headingRef}
          tabIndex={-1}
        >
          {spotlight.headline}
        </h1>
        <div className={styles.bodyCopy}>
          {spotlight.body.map((line) => (
            <p key={line}>{line}</p>
          ))}
        </div>
      </div>

      <div className={styles.bottomBar}>
        <time className={styles.countdown} dateTime={`PT${Math.ceil(remainingMs / 1000)}S`}>
          {formatRemainingSeconds(remainingMs)}
        </time>
        {slot < maxSpotlights ? (
          <button className={styles.actionNowButton} type="button" onClick={onActionNow}>
            ICH BIN WIEDER DA - HANDLUNG WAEHLEN
          </button>
        ) : null}
        <button
          className={styles.secondaryButton}
          type="button"
          onClick={isPaused ? onResume : onPause}
        >
          {isPaused ? 'FORTSETZEN' : 'PAUSE'}
        </button>
        <button className={styles.secondaryButton} type="button" onClick={onExit}>
          Akutmodus verlassen
        </button>
      </div>
    </section>
  );
}

function ActionScreen({
  headingRef,
  onSelect,
}: {
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  onSelect: (actionId: NotfallActionId) => void;
}) {
  return (
    <section className={styles.screen} aria-labelledby="notfall-action-title">
      <div className={styles.topBar}>
        <span>GENUG GEDACHT</span>
        <span>HANDLUNG</span>
      </div>
      <div className={styles.centerStage}>
        <h1
          id="notfall-action-title"
          className={`${styles.title} ${styles.spotlightShort}`}
          ref={headingRef}
          tabIndex={-1}
        >
          GENUG GEDACHT.
        </h1>
        <p className={styles.lede}>Jetzt folgt eine Handlung.</p>
      </div>
      <div className={styles.actionGrid}>
        {notfallActions.map((action) => (
          <button
            key={action.id}
            className={styles.actionButton}
            type="button"
            onClick={() => onSelect(action.id)}
          >
            {action.label}
          </button>
        ))}
      </div>
    </section>
  );
}

function ActionSelectedScreen({
  headingRef,
  actionId,
  onExit,
}: {
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  actionId: NotfallActionId;
  onExit: () => void;
}) {
  const action = actionLookup.get(actionId);

  return (
    <section className={styles.screen} aria-labelledby="notfall-confirmation-title">
      <div className={styles.topBar}>
        <span>HANDLUNG GEWAEHLT</span>
        <span>JETZT</span>
      </div>
      <div className={styles.centerStage}>
        <h1
          id="notfall-confirmation-title"
          className={styles.actionTitle}
          ref={headingRef}
          tabIndex={-1}
        >
          {action?.label}
        </h1>
        <div className={styles.bodyCopy}>
          {action?.confirmation.map((line) => (
            <p key={line}>{line}</p>
          ))}
        </div>
      </div>
      <div className={styles.bottomBar}>
        <button className={styles.primaryButton} type="button" onClick={onExit}>
          Seite schliessen
        </button>
      </div>
    </section>
  );
}

function formatRemainingSeconds(remainingMs: number): string {
  return String(Math.max(Math.ceil(remainingMs / 1000), 0)).padStart(2, '0');
}

function toCssName(value: string): string {
  return value
    .split('-')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join('');
}

function storeLocalEvent(payload: Record<string, unknown>) {
  try {
    const key = 'notfall:events';
    const previous = JSON.parse(window.localStorage.getItem(key) ?? '[]') as unknown[];
    window.localStorage.setItem(
      key,
      JSON.stringify([
        ...previous.slice(-49),
        { ...payload, createdAt: new Date().toISOString() },
      ]),
    );
  } catch {
    // Local analytics are optional and must never interrupt the emergency flow.
  }
}

function isSpotlightViewState(
  state: ReturnType<typeof useNotfallFlow>[0],
): state is Extract<ReturnType<typeof useNotfallFlow>[0], { slot: number }> {
  return 'slot' in state;
}
