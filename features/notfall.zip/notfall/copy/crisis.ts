import type {
  NotfallAction,
  NotfallJourneyState,
  SpotlightCopy,
  SpotlightLength,
  SpotlightViewData,
} from '../types';

const spotlightCopy: SpotlightCopy[] = [
  {
    id: 'interrupt',
    slot: 1,
    phase: 'interrupt',
    headline: 'DU BIST IM JAGDMODUS.',
    body: [
      'Du musst gerade nichts finden.',
      'Ich bemerke gerade einen Zustand.',
      'Dieser Zustand hat noch nicht entschieden, was ich tue.',
    ],
  },
  {
    id: 'reframe',
    slot: 2,
    phase: 'reframe',
    headline: '"DAS IST ES" IST ERREGUNG, KEINE OFFENBARUNG.',
    body: [
      'Du bezweifelst nicht deine Erregung.',
      'Du bezweifelst, was sie dir gerade ueber Bedeutung erzaehlt.',
    ],
  },
  {
    id: 'encounter',
    slot: 3,
    phase: 'encounter',
    headline: 'WENN DU IHRE ANTWORT SELBST SCHREIBST, BIST DU IHR NICHT BEGEGNET.',
    body: [
      'Fantasie bestimmt Gesicht, Worte, Lust und Antwort.',
      'Begegnung laesst offen, was ein anderer Mensch wirklich will.',
    ],
    alignment: 'left',
  },
  {
    id: 'saltwater',
    slot: 4,
    phase: 'interrupt',
    headline: 'DEIN DURST IST REAL.',
    body: [
      'Das bedeutet nicht, dass das, wonach du gerade greifst, Wasser ist.',
    ],
  },
  {
    id: 'body',
    slot: 5,
    phase: 'body',
    headline: 'JETZT NICHT WEITERDENKEN.',
    body: [
      'Spuere die sexuelle Aktivierung.',
      'Wo befindet sie sich im Koerper?',
      'Keine Frau.',
      'Kein Gesicht.',
      'Keine Geschichte.',
      '10 Sekunden nur Empfindung.',
    ],
    alignment: 'left',
  },
  {
    id: 'evidence',
    slot: 6,
    phase: 'evidence',
    headline: 'TAG 1 VON 56.',
    body: [
      'Der Drang sagt: "Ich muss."',
      'Aber "Ich muss" ist noch keine Handlung.',
    ],
    alignment: 'left',
  },
  {
    id: 'orientation',
    slot: 7,
    phase: 'orientation',
    headline: 'WELCHE RICHTUNG UEBST DU MIT DEINER NAECHSTEN HANDLUNG?',
    body: [
      'Rausch - Kontrolle - Jagd',
      'oder',
      'Wahrheit - Freiheit - Begegnung - Gott',
    ],
    alignment: 'left',
  },
];

export const notfallActions: NotfallAction[] = [
  {
    id: 'washingPrayer',
    label: 'WASCHUNG & GEBET',
    confirmation: [
      'WASCHUNG & GEBET.',
      'Computer aus.',
      'Waschung.',
      'Gebet.',
      'Schliesse jetzt diese Seite.',
    ],
  },
  {
    id: 'meditation',
    label: '10 MIN MEDITATION',
    confirmation: [
      '10 MINUTEN MEDITATION.',
      'Keine Frau.',
      'Kein Gesicht.',
      'Keine Szene.',
      'Keine Geschichte.',
      'Nur Koerper, Atem und Gegenwart.',
      'ZURUECK IN DIE WIRKLICHKEIT.',
      'Schliesse jetzt diese Seite.',
    ],
  },
  {
    id: 'walking',
    label: '20 MIN GEHEN',
    confirmation: [
      '20 MINUTEN GEHEN.',
      'Kein Scannen.',
      'Kein Suchen.',
      'Zurueck zur Welt.',
      'Schliesse jetzt diese Seite.',
    ],
  },
  {
    id: 'contact',
    label: 'MENSCHEN KONTAKTIEREN',
    confirmation: [
      'EINEN MENSCHEN KONTAKTIEREN.',
      'Nicht als neuen Reiz.',
      'Als wirkliche Verbindung.',
      'Schliesse jetzt diese Seite.',
    ],
  },
];

export function getSpotlightViewData(
  slot: number,
  journey: NotfallJourneyState,
): SpotlightViewData {
  const copy = slot === 6 ? getEvidenceSpotlight(journey) : selectSpotlightCopy(slot);
  const headline = resolveDynamicText(copy.headline, journey);
  const length = getSpotlightLengthClass(headline);

  return {
    slot: copy.slot,
    phase: copy.phase,
    headline,
    body: copy.body.map((line) => resolveDynamicText(line, journey)),
    length,
    alignment: copy.alignment ?? (length === 'short' ? 'center' : 'left'),
  };
}

export function getSpotlightLengthClass(text: string): SpotlightLength {
  const length = text.length;

  if (length < 45) return 'short';
  if (length < 80) return 'medium';
  if (length < 125) return 'long';

  return 'very-long';
}

function getEvidenceSpotlight(journey: NotfallJourneyState): SpotlightCopy {
  if (journey.completedDays > 0) {
    return {
      id: 'evidence-history',
      slot: 6,
      phase: 'evidence',
      headline: 'TAG {currentStageDay} VON 56.',
      body: [
        'Der Drang war schon da.',
        'Er ist wieder gegangen.',
        '{completedDays} vollstaendige Tage lang musstest du ihm nicht folgen.',
      ],
      alignment: 'left',
    };
  }

  return spotlightCopy[5];
}

function selectSpotlightCopy(slot: number): SpotlightCopy {
  const copy = spotlightCopy.find((candidate) => candidate.slot === slot);

  if (!copy) {
    throw new Error(`Missing notfall copy for slot ${slot}`);
  }

  return copy;
}

function resolveDynamicText(
  template: string,
  journey: NotfallJourneyState,
): string {
  return template
    .replaceAll('{currentStageDay}', String(journey.currentStageDay))
    .replaceAll('{completedDays}', String(journey.completedDays))
    .replaceAll('{daysAfterToday}', String(journey.daysAfterToday));
}
