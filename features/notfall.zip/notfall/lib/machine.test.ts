import { describe, expect, it } from 'vitest';

import { initialNotfallState, reduceNotfallState, spotlightDurationMs } from './machine';

describe('reduceNotfallState', () => {
  it('runs from intro into the first spotlight', () => {
    expect(reduceNotfallState(initialNotfallState, { type: 'start', nowMs: 0 })).toEqual({
      status: 'spotlight-1',
      timerState: 'running',
      slot: 1,
      remainingMs: spotlightDurationMs,
      startedAtMs: 0,
    });
  });

  it('advances only one spotlight even after a delayed tick', () => {
    const state = reduceNotfallState(initialNotfallState, { type: 'start', nowMs: 0 });

    expect(reduceNotfallState(state, { type: 'tick', elapsedMs: 60_000 })).toEqual({
      status: 'spotlight-2',
      timerState: 'running',
      slot: 2,
      remainingMs: spotlightDurationMs,
      startedAtMs: 0,
    });
  });

  it('moves to action after the seventh spotlight', () => {
    let state = reduceNotfallState(initialNotfallState, { type: 'start', nowMs: 0 });

    for (let index = 0; index < 7; index += 1) {
      state = reduceNotfallState(state, {
        type: 'tick',
        elapsedMs: spotlightDurationMs,
      });
    }

    expect(state).toEqual({ status: 'action', timerState: 'paused', startedAtMs: 0 });
  });

  it('pauses for hidden tabs and resumes without consuming elapsed time', () => {
    let state = reduceNotfallState(initialNotfallState, { type: 'start', nowMs: 0 });
    state = reduceNotfallState(state, { type: 'visibility.hidden' });
    state = reduceNotfallState(state, { type: 'tick', elapsedMs: 30_000 });

    expect(state).toMatchObject({
      status: 'spotlight-1',
      slot: 1,
      remainingMs: spotlightDurationMs,
      timerState: 'backgrounded',
    });

    state = reduceNotfallState(state, { type: 'visibility.visible' });

    expect(state).toMatchObject({
      status: 'spotlight-1',
      slot: 1,
      remainingMs: spotlightDurationMs,
      timerState: 'running',
    });
  });

  it('can leave early for immediate action', () => {
    const state = reduceNotfallState(
      reduceNotfallState(initialNotfallState, { type: 'start', nowMs: 100 }),
      { type: 'action.now' },
    );

    expect(state).toEqual({
      status: 'action',
      timerState: 'paused',
      startedAtMs: 100,
    });
  });

  it('measures time to action locally', () => {
    const state = reduceNotfallState(
      { status: 'action', timerState: 'paused', startedAtMs: 100 },
      { type: 'action.select', actionId: 'walking', nowMs: 12_100 },
    );

    expect(state).toMatchObject({
      status: 'action-confirmation',
      actionId: 'walking',
      timeToActionMs: 12_000,
    });
  });
});
