import type {
  CrisisState,
  NotfallActionId,
  SpotlightNumber,
  TimerState,
} from '../types';

export const maxSpotlights = 7;
export const spotlightDurationMs = 10_000;
export const maxAutomaticFlowDurationMs = maxSpotlights * spotlightDurationMs;
export const repeatFlowAutomatically = false;

const spotlightStates = [
  'spotlight-1',
  'spotlight-2',
  'spotlight-3',
  'spotlight-4',
  'spotlight-5',
  'spotlight-6',
  'spotlight-7',
] as const;

export type NotfallState =
  | { status: 'intro'; timerState: 'paused' }
  | {
      status: Extract<CrisisState, `spotlight-${SpotlightNumber}`>;
      timerState: TimerState;
      slot: SpotlightNumber;
      remainingMs: number;
      startedAtMs: number;
    }
  | { status: 'action'; timerState: 'paused'; startedAtMs: number }
  | {
      status: 'action-confirmation';
      timerState: 'paused';
      actionId: NotfallActionId;
      startedAtMs: number;
      actionSelectedAtMs: number;
      timeToActionMs: number;
    }
  | { status: 'exited'; timerState: 'paused' };

export type NotfallEvent =
  | { type: 'start'; nowMs: number }
  | { type: 'tick'; elapsedMs: number }
  | { type: 'pause.user' }
  | { type: 'resume.user' }
  | { type: 'visibility.hidden' }
  | { type: 'visibility.visible' }
  | { type: 'action.now' }
  | { type: 'action.select'; actionId: NotfallActionId; nowMs: number }
  | { type: 'exit' };

export const initialNotfallState: NotfallState = {
  status: 'intro',
  timerState: 'paused',
};

export function reduceNotfallState(
  state: NotfallState,
  event: NotfallEvent,
): NotfallState {
  if (event.type === 'exit') {
    return { status: 'exited', timerState: 'paused' };
  }

  if (state.status === 'intro') {
    return event.type === 'start'
      ? {
          status: 'spotlight-1',
          timerState: 'running',
          slot: 1,
          remainingMs: spotlightDurationMs,
          startedAtMs: event.nowMs,
        }
      : state;
  }

  if (isSpotlightState(state)) {
    return reduceSpotlightState(state, event);
  }

  if (state.status === 'action' && event.type === 'action.select') {
    const timeToActionMs = Math.max(event.nowMs - state.startedAtMs, 0);

    return {
      status: 'action-confirmation',
      timerState: 'paused',
      actionId: event.actionId,
      startedAtMs: state.startedAtMs,
      actionSelectedAtMs: event.nowMs,
      timeToActionMs,
    };
  }

  return state;
}

function reduceSpotlightState(
  state: Extract<NotfallState, { slot: SpotlightNumber }>,
  event: NotfallEvent,
): NotfallState {
  switch (event.type) {
    case 'tick':
      return tickSpotlight(state, event.elapsedMs);
    case 'pause.user':
      return { ...state, timerState: 'paused' };
    case 'resume.user':
      return state.timerState === 'paused'
        ? { ...state, timerState: 'running' }
        : state;
    case 'visibility.hidden':
      return state.timerState === 'running'
        ? { ...state, timerState: 'backgrounded' }
        : state;
    case 'visibility.visible':
      return state.timerState === 'backgrounded'
        ? { ...state, timerState: 'running' }
        : state;
    case 'action.now':
      return {
        status: 'action',
        timerState: 'paused',
        startedAtMs: state.startedAtMs,
      };
    default:
      return state;
  }
}

function tickSpotlight(
  state: Extract<NotfallState, { slot: SpotlightNumber }>,
  elapsedMs: number,
): NotfallState {
  if (state.timerState !== 'running' || elapsedMs <= 0) {
    return state;
  }

  const remainingMs = Math.max(state.remainingMs - elapsedMs, 0);

  if (remainingMs > 0) {
    return { ...state, remainingMs };
  }

  if (state.slot === maxSpotlights) {
    return {
      status: 'action',
      timerState: 'paused',
      startedAtMs: state.startedAtMs,
    };
  }

  const nextSlot = (state.slot + 1) as SpotlightNumber;

  return {
    status: spotlightStates[nextSlot - 1],
    timerState: 'running',
    slot: nextSlot,
    remainingMs: spotlightDurationMs,
    startedAtMs: state.startedAtMs,
  };
}

function isSpotlightState(
  state: NotfallState,
): state is Extract<NotfallState, { slot: SpotlightNumber }> {
  return spotlightStates.includes(state.status as (typeof spotlightStates)[number]);
}
